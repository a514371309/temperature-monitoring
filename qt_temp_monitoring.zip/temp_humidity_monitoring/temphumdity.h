#ifndef TEMPHUMDITY_H
#define TEMPHUMDITY_H

#include <QDialog>
#include <QtSerialPort/QSerialPort>
#include <QByteArray>
#include <QMainWindow>

namespace Ui {
class TempHumdity;
}

class TempHumdity : public QMainWindow
{
    Q_OBJECT

public:
    explicit TempHumdity(QWidget *parent = 0);
    ~TempHumdity();

private slots:
    void readSerial();
    void updateTemperature(QString);

private:
    Ui::TempHumdity *ui;

    QSerialPort *arduino;
        static const quint16 arduino_uno_vendor_id = 9025;
        static const quint16 arduino_uno_product_id = 67;
        QByteArray serialData;
        QString serialBuffer;
        QString parsed_data;
        double temperature_value;
};

#endif // TEMPHUMDITY_H
