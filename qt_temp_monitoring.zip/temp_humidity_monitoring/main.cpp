#include "temphumdity.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    TempHumdity w;
    w.setFixedSize(434,244);
    w.setWindowTitle("Reading from ds18b20 sensor");
    w.show();

    return a.exec();
}
